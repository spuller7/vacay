<?php
    //Sitename
    define('SITENAME', 'Eat Seeks');

    define('ROOT', 'vacay');
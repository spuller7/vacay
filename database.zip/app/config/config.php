<?php
    //APPROOT
    define('APPROOT', dirname(dirname(__FILE__)));

    define('PUBLICROOT', 'http://localhost/vacay/public');

    //URLROOT (Dynamic links)
    define('URLROOT', 'http://localhost/vacay');

    //Sitename
    define('SITENAME', 'Vacay');
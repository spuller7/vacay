<div class='container'>
<div class="row">
    <h1>Admin Page</h1>
</div>
    <div class="row">
        <div class="autocomplete" style="display:inline-flex;">
            <input id="suggestionInput" type="text" style="width:20vw;" class="form-control" name="" value='' data-place_id='' placeholder='Search...'>

            <div></div>

            <button id="recommendButton" style="white-space: nowrap;">Submit</button>
        </div>
    </div>
    <div class="row">
        <div># of Recommendations: <span id='numRecommendations'></span></div>
    </div>
</div>
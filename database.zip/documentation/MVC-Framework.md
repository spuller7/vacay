The MVC (Model View Controller) is a popular framework structure which separates the frontend and backend and joined by the controller.

~Model~
The model is a database object. Each table should have a class object associated with it. For this project, we utilize the PDO idea (PHP Database Object). The object class has properties to a CRUD object (Create Read Update Destroy) with functions to manage that object. The benefits of using a PDO enable validation within the object before creating or removing it and can be used to access properties of the object without worrying about multiple queries.

~View~

~Controller~